Some databases of ygopro.

They are for now just for test.